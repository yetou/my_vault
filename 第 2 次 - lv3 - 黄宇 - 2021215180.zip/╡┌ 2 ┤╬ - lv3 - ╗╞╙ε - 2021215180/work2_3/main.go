package main//判断类型

import (
	"fmt"
	"strconv"
)

func main(){
	var a interface{}
	var str string
	fmt.Println("please inter something")
	fmt.Scanln(&str)
	a=str
	b,err := strconv.ParseInt(str,10,64)
	if err == nil{
		a=b
	}else{
		b2,err2 := strconv.ParseFloat(str,64)
		if err2 == nil{
			a=b2
		}else{
			b3,err3 := strconv.ParseInt(str,10,64)
			if err3 == nil{
				a=b3
			}
		}
	}
	if str =="true"{
		a=true
	}
	fmt.Printf("%v的类型为%T\n",a,a)
}
