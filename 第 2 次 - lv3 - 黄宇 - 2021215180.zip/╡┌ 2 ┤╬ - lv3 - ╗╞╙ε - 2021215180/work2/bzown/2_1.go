package bzown

type Author struct{
	Name string
	VIP bool
	Icon string
	Signature string
	Focus int
}
type Sl struct{
	Good int
	Give int
	Collection int
	Zf int
}
type Sp struct{
	Author
	Sl
}
type Sp1 struct{
	Sp
	Video string
}
type Inter interface{
	Goods()
	Collect()
	Gei()
}



func (p *Sl)Goods(){	//方法
	p.Good += 1

}
func (p *Sl)Collect(){	//方法
	p.Collection += 1

}
func (p *Sl)Gei(){	//方法
	p.Give += 1

}



