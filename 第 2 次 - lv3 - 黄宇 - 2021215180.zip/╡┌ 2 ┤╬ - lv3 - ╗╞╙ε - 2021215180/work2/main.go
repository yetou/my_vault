package main

import (
	"fmt"
	"work2/bzown"
)
func Fb(p *bzown.Sp1){
	fmt.Println("请输入作者名")
	fmt.Scanf("%v",&p.Name)
	fmt.Println("请输入视频号")
	fmt.Scanf("%v",&p.Video)
	fmt.Println("创建成功!")
	fmt.Println("视频号：",p.Video)
	fmt.Println("作者信息：",p.Author)
	fmt.Println("视频信息：",p.Sl)
}

func main(){

	var own = bzown.Sp{
		bzown.Author{
			Name: "我跟白敬亭私奔了",
			VIP: false,
			Icon: "nil",
			Signature: "娱乐圈墙头草 哪边好看往哪倒听说偷视频的都被我抓去听白拉普唱rap了",
			Focus: 192,
		},
		bzown.Sl{
			Good:1111,
			Give:2222,
			Collection:3333,
			Zf:4444,
		},
	}
	fmt.Println(own)
	var i string
	fmt.Printf("想要一键三连吗亲y or n\n")
	fmt.Scan(&i)
	if i =="y" || i =="Y"{
		(&own).Goods()
		(&own).Collect()
		(&own).Gei()

	}else{
	fmt.Printf("点赞吗亲y or n\n")
	fmt.Scan(&i)
	if i == "y" || i == "Y"{
		(&own).Goods()
	}
	fmt.Printf("投币吗亲y or n\n")
	fmt.Scan(&i)
	if i == "y" || i == "Y"{
		(&own).Gei()
	}
	fmt.Printf("收藏吗亲y or n\n")
	fmt.Scan(&i)
	if i == "y" || i == "Y"{
		(&own).Collect()
	}}
	fmt.Println(own)
	var p bzown.Sp1

	Fb(&p)
}

